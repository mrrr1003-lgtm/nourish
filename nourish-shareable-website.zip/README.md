# nourish. — shared food journal

A free static food and nutrition tracking website. The same website URL works for everyone, but each person's profile and diary is saved only in their own browser (localStorage). No login, cloud sync, or shared database.

## Publish on GitHub Pages

1. Sign in at github.com and click **New repository**.
2. Name it `nourish`, choose **Public**, and create it.
3. Click **Add file → Upload files**. Upload `index.html` from this folder (do not upload the ZIP itself). Click **Commit changes**.
4. Go to **Settings → Pages**, under **Build and deployment** choose **Deploy from a branch**, select `main` and `/(root)`, then click **Save**.
5. After deployment, GitHub Pages will show a live link, usually `https://YOUR-USERNAME.github.io/nourish/`.

Or use Cloudflare Pages: Workers & Pages → Create application → Pages → Direct Upload, and upload the ZIP or the folder.

## Features and limitations

- Responsive daily dashboard, meal diary, editable profile, manual food logging, food database searches, and export/import.
- Search for packaged foods uses Open Food Facts and requires internet.
- Optional AI photo recognition downloads a third-party model. It may be unavailable on some devices/browsers, and cannot accurately quantify food calories from photos.
- Foods, photos and calorie estimates are **not guaranteed accurate**. Weigh portions and verify labels when accuracy matters.
- No account system: local browser data is private to that browser but can be lost on clearing data. Each user should periodically export their entries.
- Never publish personal information, API tokens, or private diary data in the repository.
